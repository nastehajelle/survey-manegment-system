const express = require('express');
const connectDB = require('./config/db');
const userRoutes = require('./Routes/userRoutes');

const app = express();



const path = require('path');
// Set up views folder and view engine
app.set('views', path.join(__dirname, 'pages')); // Point to the pages folder
app.set('view engine', 'ejs');

// Route for dashboard
app.get('/dashboard', (req, res) => {
  res.render('dashboard'); // Looks in the pages folder
});

// Route for index
app.get('/user', (req, res) => {
  res.render('user'); // Adjust if 'User side' is a subdirectory within pages
});

app.get('/survey_management', (req, res) => {
  res.render('survey_management'); // Assuming 'order.ejs' is the template
});




// Database connection
connectDB();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')))

// View engine setup
app.set('view engine', 'ejs');           // Set view engine to EJS
app.set('views', './views');             // Set views folder
// User routes
app.use('/', userRoutes);

// Server listen
const PORT = process.env.PORT || 3008;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
